default[:minitest][:path] = "/var/chef/minitest"
