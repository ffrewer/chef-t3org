maintainer       "Bryan McLellan"
maintainer_email "btm@loftinjas.org"
license          "Apache 2.0"
description      "Installs and configures minitest-chef-handler"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.0.5"
