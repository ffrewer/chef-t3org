## v0.99.14:

* [COOK-1065] - use pip in virtualenv during deploy

## v0.99.12:

* [COOK-606] application cookbook deployment recipes should use ipaddress instead of fqdn

## v0.99.11:

* make the _default chef_environment look like production rails env

## v0.99.10:

* Use Chef 0.10's `node.chef_environment` instead of `node['app_environment']`.
