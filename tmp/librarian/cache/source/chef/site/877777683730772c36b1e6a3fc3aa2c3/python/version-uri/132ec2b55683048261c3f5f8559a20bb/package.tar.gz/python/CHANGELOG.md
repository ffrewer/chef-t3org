## v1.0.6:

* [COOK-1036] - correctly grep for python-module version
* [COOK-1046] - run pip inside the virtualenv

## v1.0.4:

* [COOK-960] - add timeout to python_pip
* [COOK-651] - 'install_path' not correctly resolved when using python::source
* [COOK-650] - Add ability to specify version when installing distribute.
* [COOK-553] - FreeBSD support in the python cookbook
